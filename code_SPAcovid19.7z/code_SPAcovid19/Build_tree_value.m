function value = Build_tree_value(F, A, y, sequence, T)
%%%%%%%%%%%%%%%%%%%%%%%%
%  Build_tree_value
%
% Given a sequence, this function calculates the value of the node; that
% is, the contribution from the node
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%

if T == 0
    value=0;
else
    component = y(sequence(1),1);
    for t=2:T
        component = component * A(sequence(t), sequence(t-1));
    end

    value = F(1,sequence(T)) * component;
end    
end